# Status Report

#### Your name

Edbert Wu

#### Your section leader's name

Matt Fu

#### Project title

NBA Enneagram

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

We have finalized the survey questions and created the database for all the NBA teams.

#### What have you not done for your project yet?

We are now working on the html and Python side of things.

#### What problems, if any, have you encountered?

Trying to figure out why our jinja syntax from layout.html doesn't work in our other html files like index.html
