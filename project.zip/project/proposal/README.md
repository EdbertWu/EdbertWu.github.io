# Proposal

## What will (likely) be the title of your project?

Which NBA team fits your personality? (name is subject to change b/c we're trying to think of something catchier)

## In just a sentence or two, summarize your project. (E.g., "A website that lets you buy and sell stocks.")

A website that matches you to an NBA team based on your personality.

## In a paragraph or more, detail your project. What will your software do? What features will it have? How will it be executed?

We want to create a website using Flask(Jinja) that has a homepage and a survey page with various questions about personality. 
Our website will use HTML and CSS, as well as Javascript to make it more user-friendly. 
A key part of the project will be writing the questions and answers and assigning personalities to the 30 teams. 
We plan on making a dataset with the teams and their assigned groups. 
We will then use python to code an algorithm to weigh responses to our survey questions and match the user with a team. 

## If planning to combine CS50's final project with another course's final project, with which other course? And which aspect(s) of your proposed project would relate to CS50, and which aspect(s) would relate to the other course?

Not applicable

## If planning to collaborate with 1 or 2 classmates for the final project, list their names, email addresses, and the names of their assigned TFs below.

Michael Mahoney, michaelmahoney@college.harvard.edu, Andrew Yun

## In the world of software, most everything takes longer to implement than you expect. And so it's not uncommon to accomplish less in a fixed amount of time than you hope.

### In a sentence (or list of features), define a GOOD outcome for your final project. I.e., what WILL you accomplish no matter what?

Matching users with an NBA team based on their responses.

### In a sentence (or list of features), define a BETTER outcome for your final project. I.e., what do you THINK you can accomplish before the final project's deadline?

Matching users with an NBA team and direct the user to relevant information about the team (team website, team social media etc.).

### In a sentence (or list of features), define a BEST outcome for your final project. I.e., what do you HOPE to accomplish before the final project's deadline?

Matching users with an NBA team and a player on that team to root for and direct the user to relevant information (team website, player wikipedia, player instagram, etc.).

## In a paragraph or more, outline your next steps. What new skills will you need to acquire? What topics will you need to research? If working with one of two classmates, who will do what?

Our main overall goals are to create our website using Flask, group the NBA teams into specific categories (e.g. high profile, low-key), create survey questions, and create our own dataset for the category of teams. 
The main skill that we will need to acquire/learn is understanding how the weighting system will work for our survey. 
For our website, we will have a homepage, a questions page, and a results page where the user will have their matched team shown to them. 
We will officially begin working on April 20th when the test is over. 
We plan on meeting at least two times a week to work on our project. 
In terms of splitting the work, we will both work on the grouping of teams and creating questions. 
For the coding portion, we will split tasks like creating the homepage or the questions page; we will delegate specifics when we officially start. 
Even though we’re splitting the work, we know there’ll be challenges along the way, which we plan on addressing but asking each other for help.
