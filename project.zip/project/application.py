import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///teams.db")

@app.route("/")
def index():
    """Welcome user to home page"""

    # Provide variable name and pass into sell.html template
    return render_template("index.html")

@app.route("/quiz", methods=["GET", "POST"])
def quiz():
    """Have user take the quiz."""

    if request.method == "POST":

        # Calculate score for answer1
        answer1 = request.form.get("question1")
        score = 15

        if answer1 == "a":
            score = score - 2

        if answer1 == "b":
            score = score - 1

        if answer1 == "c":
            score = score + 0

        if answer1 == "d":
            score = score + 1

        if answer1 == "e":
            score = score + 2

        #Calculate score for answer2
        answer2 = request.form.get("question2")

        if answer2 == "a":
            score = score - 2

        if answer2 == "b":
            score = score - 1

        if answer2 == "c":
            score = score + 0

        if answer2 == "d":
            score = score + 1

        if answer2 == "e":
            score = score + 2

        #Calculate score for question 3
        answer3 = request.form.get("question3")

        if answer3 == "a":
            score = score - 2

        if answer3 == "b":
            score = score - 1

        if answer3 == "c":
            score = score + 0

        if answer3 == "d":
            score = score + 1

        if answer3 == "e":
            score = score + 2

        #Calculate score for question 4
        answer4 = request.form.get("question4")

        if answer4 == "a":
            score = score - 2

        if answer4 == "b":
            score = score - 1

        if answer4 == "c":
            score = score + 0

        if answer4 == "d":
            score = score + 1

        if answer4 == "e":
            score = score + 2

        #Calculate score for question 5
        answer5 = request.form.get("question5")

        if answer5 == "a":
            score = score - 2

        if answer5 == "b":
            score = score - 1

        if answer5 == "c":
            score = score + 0

        if answer5 == "d":
            score = score + 1

        if answer5 == "e":
            score = score + 2

        #Calculate score for question 6
        answer6 = request.form.get("question6")

        if answer6 == "a":
            score = score - 2

        if answer6 == "b":
            score = score - 1

        if answer6 == "c":
            score = score + 0

        if answer6 == "d":
            score = score + 1

        if answer6 == "e":
            score = score + 2

        #Calculate score for question 7
        answer7 = request.form.get("question7")

        if answer7 == "a":
            score = score - 2

        if answer7 == "b":
            score = score - 1

        if answer7 == "c":
            score = score + 0

        if answer7 == "d":
            score = score + 1

        if answer7 == "e":
            score = score + 2

        #Calculate score for quesion 8
        answer8 = request.form.get("question8")

        if answer8 == "a":
            score = score - 2

        if answer8 == "b":
            score = score - 1

        if answer8 == "c":
            score = score + 0

        if answer8 == "d":
            score = score + 1

        if answer8 == "e":
            score = score + 2

        #Calculate score for question 9
        answer9 = request.form.get("question9")

        if answer9 == "a":
            score = score - 2

        if answer9 == "b":
            score = score - 1

        if answer9 == "c":
            score = score + 0

        if answer9 == "d":
            score = score + 1

        if answer9 == "e":
            score = score + 2

        #Calculate score for question 10
        answer10 = request.form.get("question10")

        if answer10 == "a":
            score = score - 2

        if answer10 == "b":
            score = score - 1

        if answer10 == "c":
            score = score + 0

        if answer10 == "d":
            score = score + 1

        if answer10 == "e":
            score = score + 2

        if score <= 1:
            score = 1

        if score >= 30:
            score = 30

        #We found some of this code from https://stackoverflow.com/questions/902408/how-to-use-variables-in-sql-statement-in-python
        team = db.execute("SELECT team_name FROM teams WHERE team_score =?", (score))

        return render_template("results.html", team_name=team)


    else:
        return render_template("quiz.html")

@app.route("/results", methods=["GET", "POST"])
def results():
    """Have user take the quiz."""

    # User reached method via POST
    if request.method == "POST":

        return render_template("results.html")

    # User reached method via GET
    else:
        return render_template("results.html")